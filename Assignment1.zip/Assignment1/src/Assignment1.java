//Name: Karthik Rajendran
//Student_id: C0891346
//Assignment 1
import java.util.Scanner;

class Point {
    private double x;
    private double y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
//To calculate the distance between the points
    public double calculateDistance(Point other) {
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}

class Triangle {
    private Point v1;
    private Point v2;
    private Point v3;

    public Triangle(Point v1, Point v2, Point v3) {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
    }
//To calculate the perimeter of the Triangle
    public double calculatePerimeter() {
        double side1 = v1.calculateDistance(v2);
        double side2 = v2.calculateDistance(v3);
        double side3 = v3.calculateDistance(v1);
        return side1 + side2 + side3;
    }

    public boolean isIsosceles() {
        double side1 = v1.calculateDistance(v2);
        double side2 = v2.calculateDistance(v3);
        double side3 = v3.calculateDistance(v1);
        return (side1 == side2) || (side2 == side3) || (side3 == side1);
    }
}

public class Assignment1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int no_of_triangles;

        do {
            System.out.print("Enter the number of triangles minimum three: ");
            no_of_triangles = scanner.nextInt();
        } while (no_of_triangles < 3);

        Triangle[] triangles = new Triangle[no_of_triangles];

        for (int i = 0; i < no_of_triangles; i++) {
            System.out.println("Creating a new triangle:");
            Point v1 = createPoint(scanner);
            Point v2 = createPoint(scanner);
            Point v3 = createPoint(scanner);
            Triangle triangle = new Triangle(v1, v2, v3);
            triangles[i] = triangle;
        }

        for (int i = 0; i < no_of_triangles; i++) {
            double perimeter = triangles[i].calculatePerimeter();
            System.out.println("Triangle " + (i + 1) + " Perimeter: " + perimeter);
            if (triangles[i].isIsosceles()) {
                System.out.println("Triangle " + (i + 1) + " is isosceles.");
            }
        }

        System.out.println("Please enter a point to check if there is inside any triangle:");
        Point newpoint = createPoint(scanner);

        for (int i = 0; i < no_of_triangles; i++) {
            if (isPointInsideTriangle(newpoint, triangles[i])) {
                System.out.println("The point is inside Triangle " + (i + 1));
            }
        }
    }

    private static Point createPoint(Scanner scanner) {
        System.out.print("Please enter the value of x: ");
        double x = scanner.nextDouble();
        System.out.print("Please enter the value of y: ");
        double y = scanner.nextDouble();
        return new Point(x, y);
    }

    private static boolean isPointInsideTriangle(Point point, Triangle triangle) {
        return false;
    }
}